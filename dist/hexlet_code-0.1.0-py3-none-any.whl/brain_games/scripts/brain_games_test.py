#!/usr/bin/env python3
import sys
from brain_games import cli
sys.path.append('../')


def main():
    cli.welcome_user()


if __name__ == '__main__':
    main()
