### Hexlet tests and linter status:
[![Actions Status](https://github.com/Morphlike/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Morphlike/python-project-49/actions)
[![Test Coverage](https://api.codeclimate.com/v1/badges/907f9003d89cef7468cc/test_coverage)](https://codeclimate.com/github/Morphlike/python-project-49/test_coverage)